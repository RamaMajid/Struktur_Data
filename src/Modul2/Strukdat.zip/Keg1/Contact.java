package Modul2.Keg1;

public class Contact {
    String nama;
    String nomor;

    public Contact(String nama, String nomor){
        this.nama = nama;
        this.nomor = nomor;
    }
}
