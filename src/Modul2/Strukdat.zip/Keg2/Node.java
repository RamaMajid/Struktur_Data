package Modul2.Keg2;

public class Node {
    Contact contact;
    Node next;

    public Node(Contact contact) {
        this.contact = contact;
    }
}
