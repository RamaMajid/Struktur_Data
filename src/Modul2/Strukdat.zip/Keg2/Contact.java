package Modul2.Keg2;

public class Contact {
    String nama;
    String nomor;

    public Contact(String nama, String nomor){
        this.nama = nama;
        this.nomor = nomor;
    }
}
